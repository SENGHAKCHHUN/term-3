<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Canlender</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
        button {
            background: orange;
            margin-left: 86%;
            border: none;
            border-radius: 10px;
            padding: 10px;
        }
    </style>
</head>

<body>

    <h2>
        <center>Full canlender JS</center>

    </h2>
    <button class="btn">Create Event</button>
    <div class="container">
        <div id="calendar"></div>
    </div>

</html>
<script>
    let add = document.querySelector('.btn');
    add.addEventListener('click', function(){
        $('#myModal').modal('toggle');
    })
    $(document).ready(function() {
        $('#calendar').fullCalendar({
            // dayClick: function(date, allDay, jsEvent, view) {
            //     var formattedDate = date.toString().replace(" GMT+0000", "");
            //     alert(formattedDate );
            // },
            scrollTime: '07:00:00',
            minTime: '07:00:00',
            maxTime: '18:00:00',
            defaultView: 'agendaWeek',
            hiddenDays: [0],
            alldayslot: false,
            selectable: true,
            selectHelper: true,
            select: function() {
                $('#myModal').modal('toggle');
            },
            header: {
                left: 'month, agendaWeek, agendaDay, list',
                center: 'title',
                right: 'prev, today, next',
            },
            buttonText: {
                week: 'Week',
                today: 'Today',
                day: 'Day',
                month: 'Month',
                list: 'List',
            },
            events: [{
                    title: 'Node',
                    start: '2024-01-29T07:30',
                    end: '2024-01-29T09:00',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Professional life',
                    start: '2024-01-29T10:00',
                    end: '2024-01-29T11:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Database',
                    start: '2024-01-29T13:00',
                    end: '2024-01-29T14:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Khmer Debate',
                    start: '2024-01-29T15:30',
                    end: '2024-01-29T17:00',
                    color: 'orange',
                    textColor: 'white',
                }, {
                    title: 'General',
                    start: '2024-01-30T07:30',
                    end: '2024-01-30T09:00',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Database',
                    start: '2024-01-30T10:00',
                    end: '2024-01-30T11:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Database',
                    start: '2024-01-30T13:00',
                    end: '2024-01-30T14:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Grammar study',
                    start: '2024-01-30T15:30',
                    end: '2024-01-30T17:00',
                    color: 'orange',
                    textColor: 'white',
                }, {
                    title: 'Node',
                    start: '2024-01-31T07:30',
                    end: '2024-01-31T09:00',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Database',
                    start: '2024-01-31T10:00',
                    end: '2024-01-31T11:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Paragraph Writting',
                    start: '2024-01-31T13:00',
                    end: '2024-01-31T14:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Project Management',
                    start: '2024-01-31T15:30',
                    end: '2024-01-31T17:00',
                    color: 'orange',
                    textColor: 'white',
                }, {
                    title: 'General English',
                    start: '2024-02-01T07:30',
                    end: '2024-02-01T09:00',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Professional life',
                    start: '2024-02-01T10:00',
                    end: '2024-02-01T11:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Database',
                    start: '2024-02-01T13:00',
                    end: '2024-02-01T14:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Node',
                    start: '2024-02-01T15:30',
                    end: '2024-02-01T17:00',
                    color: 'orange',
                    textColor: 'white',
                }, {
                    title: 'Database',
                    start: '2024-02-02T07:30',
                    end: '2024-02-02T09:00',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Project Management',
                    start: '2024-02-02T10:00',
                    end: '2024-02-02T11:30',
                    color: 'orange',
                    textColor: 'white',
                }, {
                    title: "Student's Meeting",
                    start: '2024-02-02T13:00',
                    end: '2024-02-02T14:30',
                    color: 'orange',
                    textColor: 'white',
                },
                {
                    title: 'Sport Session',
                    start: '2024-02-02T15:30',
                    end: '2024-02-02T17:00',
                    color: 'orange',
                    textColor: 'white',
                }
            ],
            dayRender: function(date, cell) {
                var today = $.fullCalendar.moment();
                if (date.get('date') == today.get('date')) {
                    cell.css('background', 'greenyellow');
                }
                var newdate = $.fullCalendar.formatDate(date, 'DD-MM-YYYY');
                if (newdate == '03-02-2024') {
                    cell.css('background', 'orange');
                } else if (newdate == '24-01-2024') {
                    cell.css('background', 'blue')
                }
            }
        });
    })

    let title = document.querySelector('.title');
    let start = document.querySelector('.start');
    let end = document.querySelector('.end');
    let submit = document.querySelector('.submit');
    submit.addEventListener('click', function)
    console.log(submit);
    console.log(title)
    console.log(start)
    console.log(end)
</script>

<?php
require_once "AddEvent.php";
?>